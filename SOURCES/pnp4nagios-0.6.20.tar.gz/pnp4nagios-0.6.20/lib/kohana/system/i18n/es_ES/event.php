<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'invalid_subject' => 'Fallo el intento de añadir el sujeto %s a %s. Los sujetos deben extender la clase Event_Subject.',
	'invalid_observer' => 'Fallo el intento de añadir el observador %s a %s. Los observadores deben extender la clase Event_Observer.',
);

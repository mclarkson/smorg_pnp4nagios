<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'invalid_subject'  => 'Попытка привязать некорректный субъект %s к %s не удалась: Субъект должен быть наследником класса Event_Subject',
	'invalid_observer' => 'Попытка привязать некорректный наблюдатель %s к %s не удалась: Наблюдатель должен быть наследником класса Event_Observer',
);

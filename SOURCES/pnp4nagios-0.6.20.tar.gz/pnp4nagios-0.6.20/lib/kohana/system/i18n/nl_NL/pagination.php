<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'undefined_group' => 'De %s groep werd niet gedefinieerd in uw pagination configuratie.',
	'page'     => 'pagina',
	'pages'    => 'pagina\'s',
	'item'     => 'item',
	'items'    => 'items',
	'of'       => 'van',
	'first'    => 'eerste',
	'last'     => 'laatste',
	'previous' => 'vorige',
	'next'     => 'volgende',
);

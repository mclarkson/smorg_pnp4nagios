<?php defined('SYSPATH') OR die('No direct access allowed.');

/**
 * Retrieves the PNP config files 
 */
class System_Model extends Model {

    public $ERROR = NULL;

    public function __construct() {

    }

}

<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'general_error' => 'Ocurrió un error mientras se realizaba el envio del mensaje de correo.',
);